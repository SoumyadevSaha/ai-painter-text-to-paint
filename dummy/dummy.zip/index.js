const express = require('express');
const axios = require('axios');
const app = express();
const port = 3003;

app.get('/', (req, res) => {
    res.send('Hello World!');
});

app.post('/api', async (req, res) => {
    const prompt = req.body;

    const axios = require('axios');

    const data = JSON.stringify({
        "prompt": "AI plays chess",
        "n": 1,
        "size": "1024x1024"
    });

    const options = {
        method: 'POST',
        url: 'https://openai80.p.rapidapi.com/images/generations',
        headers: {
            'user-agent': 'Mozilla/5.0 (Linux; Android 6.0; Nexus 5 Build/MRA58N) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Mobile Safari/537.36',
            'content-type': 'application/json',
            'X-RapidAPI-Key': '9609f03343msh6c6f56ddd2968c3p1b746ajsn182e75ab4a26',
            'X-RapidAPI-Host': 'openai80.p.rapidapi.com'
        },
        data: data
    };
    try {
        const response = await axios.request(options);
        console.log(response.data);
        res.send(response.data)
    } catch (error) {
        console.error(error.response.data);
        // res.send(error.response);
    }
});

app.listen(port, () => {
    console.log(`Example app listening at http://localhost:${port}`);
});